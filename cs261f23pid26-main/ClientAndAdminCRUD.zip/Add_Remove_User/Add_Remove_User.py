from PyQt5 import QtCore, QtWidgets
from PyQt5.QtWidgets import QMainWindow, QTableWidgetItem, QLineEdit, QLabel, QInputDialog, QMessageBox
import sys
from linked_list import LinkedList
import csv

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1200, 800)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("central widget")
        self.centralwidget.setStyleSheet("background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #E2EDF7, stop: 1 #B6CCF0);")

        self.centralLayout = QtWidgets.QVBoxLayout(self.centralwidget)

        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setStyleSheet("background: rgba(0, 0, 0, 100); color: white; font: 20pt 'Arial Rounded MT Bold';")
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setText("Add Remove User")
        self.centralLayout.addWidget(self.label)

        self.horizontalWidget = QtWidgets.QWidget(self.centralwidget)
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.horizontalWidget)
        self.centralLayout.addWidget(self.horizontalWidget)

        self.sidebarWidget = QtWidgets.QWidget(self.horizontalWidget)
        self.sidebarLayout = QtWidgets.QVBoxLayout(self.sidebarWidget)
        self.sidebarWidget.setMaximumWidth(150)
        self.sidebarWidget.setStyleSheet("background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #B6CCF0, stop: 1 #E2EDF7);")
        self.horizontalLayout.addWidget(self.sidebarWidget)

        self.pushButton_add_user = QtWidgets.QPushButton(self.sidebarWidget)
        self.pushButton_add_user.setText("Add User")
        self.sidebarLayout.addWidget(self.pushButton_add_user)
        self.pushButton_add_user.clicked.connect(self.add_user)

        self.pushButton_remove_user = QtWidgets.QPushButton(self.sidebarWidget)
        self.pushButton_remove_user.setText("Remove User")
        self.sidebarLayout.addWidget(self.pushButton_remove_user)
        self.pushButton_remove_user.clicked.connect(self.remove_user)

        self.gridWidget = QtWidgets.QWidget(self.horizontalWidget)
        self.gridLayout = QtWidgets.QGridLayout(self.gridWidget)
        self.gridWidget.setStyleSheet("background: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 #B6CCF0, stop: 1 #E2EDF7);")
        self.horizontalLayout.addWidget(self.gridWidget)

        self.tableWidget = QtWidgets.QTableWidget(self.gridWidget)
        self.tableWidget.setObjectName("tableWidget")
        self.tableWidget.setColumnCount(4)
        self.tableWidget.setHorizontalHeaderLabels(["Passenger ID", "Name", "Email", "Phone"])
        self.gridLayout.addWidget(self.tableWidget, 0, 0, 1, 2)

        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        MainWindow.setStatusBar(self.statusbar)
        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def close_application(self):
        sys.exit()

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Add Remove User"))


    def read_data_from_csv(file_path):
        data = []
        with open(file_path, 'r', newline='') as csvfile:
            csv_reader = csv.reader(csvfile)
            for row in csv_reader:
                data.append(row)
        return data
    
    def load_data_into_grid(self, data):
        self.tableWidget.setRowCount(len(data))
        self.tableWidget.setColumnCount(len(data[0]))
        for row_idx, row_data in enumerate(data):
            for col_idx, cell_data in enumerate(row_data):
                item = QTableWidgetItem(str(cell_data))
                self.tableWidget.setItem(row_idx, col_idx, item)


    def load_data_from_file(self,file_path):
        data = read_data_from_csv(file_path)
        self.load_data_into_grid(data)

    def get_table_data(self):
        data = []
        for row in range(self.tableWidget.rowCount()):
            row_data = []
            for col in range(self.tableWidget.columnCount()):
                cell_text = self.tableWidget.item(row, col).text()
                row_data.append(cell_text)
            data.append(row_data)
        return data    

    def add_user(self):
            name, ok = QInputDialog.getText(self.centralwidget, "Add User", "Enter Name:")
            if ok:
                email, ok = QInputDialog.getText(self.centralwidget, "Add User", "Enter Email:")
                if ok:
                    phone, ok = QInputDialog.getText(self.centralwidget, "Add User", "Enter Phone:")
                    if ok:
                        id, ok = QInputDialog.getText(self.centralwidget,"Add User", "Enter ID:")
                        if ok:
                            user_data = {"Passenger ID": id, "Name": name, "Email": email, "Phone": phone}
                            self.linked_list.append(user_data)  # Add to the linked list

                        # Insert a new row at the end
                        current_row = self.tableWidget.rowCount()
                        self.tableWidget.insertRow(current_row)

                        # Set the user data in the new row
                        self.tableWidget.setItem(current_row, 0, QTableWidgetItem(user_data["Passenger ID"]))
                        self.tableWidget.setItem(current_row, 1, QTableWidgetItem(user_data["Name"]))
                        self.tableWidget.setItem(current_row, 2, QTableWidgetItem(user_data["Email"]))
                        self.tableWidget.setItem(current_row, 3, QTableWidgetItem(user_data["Phone"]))

    def remove_user(self):
        selected_rows = self.tableWidget.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.warning(self.centralwidget, "Warning", "No user selected for removal.")
            return

        for row in selected_rows:
            passenger_id = self.tableWidget.item(row.row(), 0).text()
            self.linked_list.remove({"Passenger ID": passenger_id})  # Remove from the linked list
            self.tableWidget.removeRow(row.row())

# Function to read data from a CSV file
def read_data_from_csv(file_path):
    data = []
    try:
        with open(file_path, 'r', newline='') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                data.append(row)
    except Exception as e:
        print(f"An error occurred: {str(e)}")
    return data

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QMainWindow()
    ui = Ui_MainWindow()
    ui.linked_list = LinkedList()
    ui.setupUi(MainWindow)
    MainWindow.show()
    ui.load_data_from_file('flight_booking_data_passengers.csv')
    sys.exit(app.exec_())
