# -*- coding: utf-8 -*-
"""
Created on Mon Dec  4 19:16:45 2023

@author: Speed
"""

import sys
import csv
import hashlib
from PyQt5.QtWidgets import QApplication, QMainWindow, QPlainTextEdit, QMessageBox
from PyQt5.uic import loadUi
from PyQt5.QtCore import QProcess

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        loadUi("dsaUI/UI1.ui", self)
 
        # For placeholder text
        self.plainTextEdit.setPlainText("Username")
        self.plainTextEdit_2.setPlainText("Password")
        # Connecting the button click event to the storeInfo method
        self.pushButton.clicked.connect(self.checkInfo)
        self.pushButton_3.clicked.connect(self.run_script)
        
    def run_script(self):
        sender_button = self.sender()
        if sender_button == self.pushButton_3:
            script_name = "takeinput.py"
            process = QProcess(self)
            process.start('python', [script_name])
            process.waitForFinished()
            

    def hashPassword(self, password):
        hash_object = hashlib.sha256(password.encode())
        hash_data = hash_object.hexdigest()
        return hash_data

    def checkPassword(self, hash_data):
        with open("passwords.csv", mode="r") as csv_file:
            csv_reader = csv.reader(csv_file)
            for row in csv_reader:
                if row and row[1] == hash_data:
                    return True
        return False

    def checkInfo(self):
        # Retrieving text from the plain text edits
        username = self.plainTextEdit.toPlainText()
        password = self.plainTextEdit_2.toPlainText()

        # Hash the password
        hash_data = self.hashPassword(password)

        # Check if the password already exists
        if self.checkPassword(hash_data):
            msg = "login successfully"
            QMessageBox.information(self, "Information Saved", msg)
        else:
            msg = "in valid username or password"
            QMessageBox.information(self, "Information Saved", msg)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
