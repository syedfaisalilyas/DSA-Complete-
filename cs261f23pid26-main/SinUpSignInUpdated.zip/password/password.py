import sys
import csv
import hashlib
import re  # Import the regular expression module
from PyQt5.QtWidgets import QApplication, QMainWindow, QPlainTextEdit, QMessageBox
from PyQt5.uic import loadUi
from PyQt5.QtCore import QProcess

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        loadUi("dsaUI/UI.ui", self)

        # For placeholder text
        self.plainTextEdit.setPlainText("Username")
        self.plainTextEdit_2.setPlainText("Password")

        # Connecting the button click event to the storeInfo method
        self.pushButton.clicked.connect(self.storeInfo)
        self.pushButton.clicked.connect(self.run_script)
        
    def run_script(self):
        sender_button = self.sender()
        if sender_button == self.pushButton_3:
            script_name = "login.py"
            process = QProcess(self)
            process.start('python', [script_name])
            process.waitForFinished()

    def hashPassword(self, password):
        hash_object = hashlib.sha256(password.encode())
        hash_data = hash_object.hexdigest()
        return hash_data

    def storePassword(self, hash_data, username, role):
        with open("passwords.csv", mode="a", newline='') as csv_file:
            csv_writer = csv.writer(csv_file)
            csv_writer.writerow([username, hash_data, role])

    def checkPassword(self, hash_data):
        with open("passwords.csv", mode="r") as csv_file:
            csv_reader = csv.reader(csv_file)
            for row in csv_reader:
                if row and row[1] == hash_data:
                    return True
        return False

    def validatePassword(self, password):
        # Check if the password has at least 8 characters, one uppercase, one lowercase, and one special character
        if len(password) < 8 or not re.search(r'[A-Z]', password) or not re.search(r'[a-z]', password) or not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            return False
        return True

    def storeInfo(self):
        username = self.plainTextEdit.toPlainText()
        password = self.plainTextEdit_2.toPlainText()
        role = self.comboBox.currentText()

        # Validate the password
        if not self.validatePassword(password):
            msg = "Password must be at least 8 characters and include one uppercase letter, one lowercase letter, and one special character."
            QMessageBox.information(self, "Invalid Password", msg)
            return

        # Hash the password
        hash_data = self.hashPassword(password)

        # Check if the password already exists
        if self.checkPassword(hash_data):
            msg = "Username or password is already exist"
            QMessageBox.information(self, "Information Saved", msg)
        else:
            # Store the user information
            self.storePassword(hash_data, username, role)
            msg = "Data stored successfully"
            QMessageBox.information(self, "Information Saved", msg)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())









