import sys
from PyQt5.uic import loadUi
from PyQt5.QtWidgets import *

from PyQt5 import QtCore, QtGui, QtWidgets
import csv
from PyQt5.QtGui import QColor
from BusinessLayer.BL import searchingMethods

from DataLayer.DL import dataLoader
class Mainwindow(QMainWindow):
    def __init__(self):
        super(Mainwindow, self).__init__()
        self.resize(903, 582)
        loadUi("UserInterface/singleLevelSearching.ui", self)

        # Initialize the DataLoader with the current UI instance
        self.data_loader = dataLoader(self)
        self.searchingMethods = searchingMethods(self)
        # Call the load_DataFromFile method from DataLoader
        file_path = "Example.csv"  # Replace with your file path
        self.data_loader.load_DataFromFile(file_path)
        self.searchButton.clicked.connect(searchingMethods.searchButtonClick(self))







app = QApplication(sys.argv)
window = Mainwindow()
window.show()
sys.exit(app.exec_())
