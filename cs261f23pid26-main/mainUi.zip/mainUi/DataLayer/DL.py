import csv
from PyQt5.uic import loadUi
from PyQt5.QtWidgets import *

from PyQt5 import QtCore, QtGui, QtWidgets
class dataLoader:
    def __init__(self, ui_instance):
        self.ui_instance = ui_instance
    def load_DataFromFile(self,path):
        with open(path, 'r', encoding='iso-8859-1',
                  errors='replace') as fileInput:
            tableRows = 0
            self.ui_instance.data = list(csv.reader(fileInput))
            self.ui_instance.tableWidget.setRowCount(len(self.ui_instance.data))
            for row in self.ui_instance.data:
                self.ui_instance.tableWidget.setItem(
                    tableRows, 0, QtWidgets.QTableWidgetItem((row[0])))
                self.ui_instance.tableWidget.setItem(
                    tableRows, 1, QtWidgets.QTableWidgetItem((row[1])))
                self.ui_instance.tableWidget.setItem(
                    tableRows, 2, QtWidgets.QTableWidgetItem((row[2])))
                self.ui_instance.tableWidget.setItem(
                    tableRows, 3, QtWidgets.QTableWidgetItem((row[3])))
                self.ui_instance.tableWidget.setItem(
                    tableRows, 4, QtWidgets.QTableWidgetItem((row[4])))
                self.ui_instance.tableWidget.setItem(
                    tableRows, 5, QtWidgets.QTableWidgetItem((row[5])))
                self.ui_instance.tableWidget.setItem(
                    tableRows, 6, QtWidgets.QTableWidgetItem((row[6])))
                self.ui_instance.tableWidget.setItem(
                    tableRows, 7, QtWidgets.QTableWidgetItem((row[7])))

                tableRows += 1

    def get_data_from_table(self, table_widget):
        flight_data = {
            'fNumber': [],
            'ftype': [],
            'pName': [],
            'capacity': [],
            'sCountry': [],
            'dCountry': [],
            'date': [],
            'duration': [],
        }

        for row in range(table_widget.rowCount()):
            flight_data['fNumber'].append(table_widget.item(row, 0).text())
            flight_data['ftype'].append(table_widget.item(row, 1).text())
            flight_data['pName'].append(table_widget.item(row, 2).text())
            flight_data['capacity'].append(table_widget.item(row, 3).text())
            flight_data['sCountry'].append(table_widget.item(row, 4).text())
            flight_data['dCountry'].append(table_widget.item(row, 5).text())
            flight_data['date'].append(table_widget.item(row, 6).text())
            flight_data['duration'].append(table_widget.item(row, 7).text())

        return flight_data





