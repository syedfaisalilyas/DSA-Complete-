import sys
from PyQt5.uic import loadUi
from PyQt5.QtWidgets import *
from PyQt5.QtCore import Qt

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.resize(1200, 800)
        loadUi("Graphs.ui", self)

        self.init_ui()

    def init_ui(self):
        # Create a central widget to manage layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Vertical layout for the central widget
        layout = QVBoxLayout()
        central_widget.setLayout(layout)

        # Title label
        title_label = QLabel("Graphs", self)
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("font-size: 100px; color: white; margin-top: 20px; margin-bottom: 20px;")
        layout.addWidget(title_label)

        # Container widget for buttons
        button_container = QWidget()
        button_layout = QVBoxLayout(button_container)
        layout.addWidget(button_container, alignment=Qt.AlignCenter)

        # Define button names
        button_names = ["SingleColSort", "MultiColSort", "SingleColSearch", "MultiColSearch"]

        # Create and configure buttons
        for button_name in button_names:
            button = getattr(self, button_name)
            button.setStyleSheet("font-size: 25px; background-color: #6495ED; color: white; padding: 15px 120px; margin: 10px;")
            button_layout.addWidget(button)

        # Set the container widget's layout
        button_container.setLayout(button_layout)

        # Ensure buttons stay relatively small when window is maximized
        for button_name in button_names:
            button = getattr(self, button_name)
            button.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
